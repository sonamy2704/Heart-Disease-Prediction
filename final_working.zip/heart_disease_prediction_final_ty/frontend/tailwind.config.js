/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        primary: {
          light: '#ff7885',
          main: '#ff5162',
          dark: '#cc2941',
        },
        secondary: {
          light: '#4dabf5',
          main: '#1976d2',
          dark: '#1565c0',
        },
        background: {
          default: '#f8f9fa',
          paper: '#ffffff',
        },
      },
      fontFamily: {
        sans: ['Poppins', 'sans-serif'],
        serif: ['Playfair Display', 'serif'],
      },
    },
  },
  plugins: [],
}
