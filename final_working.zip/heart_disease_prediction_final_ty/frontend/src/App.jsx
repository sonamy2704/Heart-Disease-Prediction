// src/App.jsx
import { useState, useEffect, useContext } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import LandingPage from './components/LandingPage';
import PredictionForm from './components/PredictionForm';
import ResultsPage from './components/ResultsPage';
import AboutPage from './components/AboutPage';
import LoginPage from './components/LoginPage';
import RegisterPage from './components/RegisterPage';
import ResetPasswordPage from './components/ResetPasswordPage';
import { AuthContext } from './context/AuthContext';

function App() {
    const [predictionResult, setPredictionResult] = useState(null);
    const [formData, setFormData] = useState(null);
    const { currentUser, loading } = useContext(AuthContext);

    const handlePredictionResult = (result, data) => {
        setPredictionResult(result);
        setFormData(data);
    };

    // Show loading indicator while checking auth state
    if (loading) {
        return <div className="flex justify-center items-center min-h-screen">Loading...</div>;
    }

    return (
        <div className="flex flex-col min-h-screen">
            <Header />
            <main className="flex-grow">
                <Routes>
                    <Route path="/login" element={<LoginPage />} />
                    <Route path="/register" element={<RegisterPage />} />
                    <Route path="/reset-password" element={<ResetPasswordPage />} />
                    <Route
                        path="/"
                        element={
                            currentUser ? (
                                <LandingPage />
                            ) : (
                                <Navigate to="/login" replace />
                            )
                        }
                    />
                    <Route
                        path="/predict"
                        element={
                            currentUser ? (
                                <PredictionForm onPredictionResult={handlePredictionResult} />
                            ) : (
                                <Navigate to="/login" replace />
                            )
                        }
                    />
                    <Route
                        path="/results"
                        element={
                            currentUser ? (
                                <ResultsPage result={predictionResult} formData={formData} />
                            ) : (
                                <Navigate to="/login" replace />
                            )
                        }
                    />
                    <Route
                        path="/about"
                        element={
                            currentUser ? (
                                <AboutPage />
                            ) : (
                                <Navigate to="/login" replace />
                            )
                        }
                    />
                    <Route path="*" element={<Navigate to="/" replace />} />
                </Routes>
            </main>
            <Footer />
        </div>
    );
}

export default App;
