// src/components/LandingPage.jsx
import React from 'react';
import { Box, Button, Container, Typography } from '@mui/material';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';

const LandingPage = () => {
  return (
    <Box
      className="bg-cover bg-center text-white font-sans"
      style={{
        backgroundImage: 'linear-gradient(to bottom, rgba(0,0,0,0.6), rgba(0,0,0,0.9)), url(/landing_bg.jpg)',
        minHeight: '100vh',
        display: 'flex',
        flexDirection: 'column',
      }}
    >
      {/* Top Section - Heading */}
      <Container maxWidth="lg" className="text-center pt-14">
        <motion.div
          initial={{ opacity: 0, y: -40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1 }}
        >
          <Typography
            variant="h1"
            className="text-6xl md:text-8xl font-bold tracking-tight text-cyan-300 drop-shadow-lg"
            style={{ fontFamily: "'Poppins', sans-serif" }}
          >
            Heart Disease Prediction
          </Typography>
        </motion.div>
      </Container>

      {/* Middle Section - Description */}
      <Container
        maxWidth="md"
        className="flex flex-col items-center justify-center text-center flex-grow"
      >
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1.2 }}
        >
          <Typography
            variant="h5"
            className="text-2xl md:text-3xl text-teal-200 font-light mb-4"
            style={{ fontFamily: "'Poppins', sans-serif" }}
          >
            Using AI to predict heart disease risk with machine learning
          </Typography>

          <Typography
            variant="body1"
            className="text-lg md:text-xl text-gray-300 mb-8 leading-relaxed"
            style={{ fontFamily: "'Poppins', sans-serif" }}
          >
            Our smart ML model analyzes your health data to assess your heart risk.
            <br />
            <span className="text-gray-100 font-semibold">Early detection saves lives.</span>
          </Typography>

          {/* Buttons - below description with space */}
          <Box className="flex justify-center gap-6 mt-10">
            <Button
              component={Link}
              to="/predict"
              variant="contained"
              size="large"
              className="bg-red-600 hover:bg-red-700 px-8 py-3 text-lg rounded-xl shadow-xl"
            >
              Start Prediction
            </Button>
            <Button
              component={Link}
              to="/about"
              variant="outlined"
              size="large"
              className="border-teal-200 text-teal-200 hover:bg-white/10 px-8 py-3 text-lg rounded-xl"
            >
              Learn More
            </Button>
          </Box>
        </motion.div>
      </Container>
    </Box>
  );
};

export default LandingPage;
