import { Container, Box, Typography, Grid, Card, CardContent, Divider } from '@mui/material';
import HealthAndSafetyIcon from '@mui/icons-material/HealthAndSafety';
import TimelineIcon from '@mui/icons-material/Timeline';
import PeopleIcon from '@mui/icons-material/People';
import SchoolIcon from '@mui/icons-material/School';
import { motion } from 'framer-motion';

const AboutPage = () => {
  return (
    <Box className="py-8">
      <Container maxWidth="lg">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <Box className="mb-12 text-center">
            <Typography variant="h3" component="h1" className="mb-4 font-serif">
              About Our Heart Disease Prediction Project
            </Typography>
            <Typography variant="subtitle1" className="text-gray-600 max-w-3xl mx-auto">
              Our mission is to leverage machine learning to help identify potential heart disease risk,
              promoting early intervention and better health outcomes.
            </Typography>
          </Box>
        </motion.div>

        <Grid container spacing={6}>
          <Grid item xs={12} md={6}>
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <Typography variant="h4" component="h2" className="mb-4 font-serif">
                Our Approach
              </Typography>
              <Typography variant="body1" className="mb-4">
                Heart disease remains the leading cause of death globally. Early detection and prevention
                are crucial for reducing mortality rates. Our machine learning model analyzes key health
                indicators to provide a risk assessment for heart disease.
              </Typography>
              <Typography variant="body1" className="mb-4">
                The model has been trained on comprehensive datasets containing thousands of patient records,
                allowing it to identify patterns that might indicate potential heart disease.
              </Typography>
              <Typography variant="body1">
                By providing a simple interface for users to input their health parameters, we aim to make
                heart disease risk assessment more accessible to everyone.
              </Typography>
            </motion.div>
          </Grid>
          
          <Grid item xs={12} md={6}>
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
            >
              <Card className="bg-gray-100 h-full">
                <CardContent>
                  <Typography variant="h5" component="h3" className="mb-4 font-serif">
                    The Dataset
                  </Typography>
                  <Typography variant="body1" className="mb-2">
                    Our model was trained using a comprehensive heart disease dataset that includes various
                    health parameters such as:
                  </Typography>
                  <ul className="list-disc pl-6 mb-4">
                    <li>Age and gender</li>
                    <li>Blood pressure readings</li>
                    <li>Cholesterol levels</li>
                    <li>Fasting blood sugar</li>
                    <li>Electrocardiographic results</li>
                    <li>Maximum heart rate achieved</li>
                    <li>Exercise-induced angina</li>
                    <li>ST depression induced by exercise</li>
                    <li>Number of major vessels</li>
                    <li>Thalassemia type</li>
                  </ul>
                  <Typography variant="body2" className="text-gray-600 italic">
                    This data helps our model to identify patterns and correlations that might indicate
                    the presence of heart disease.
                  </Typography>
                </CardContent>
              </Card>
            </motion.div>
          </Grid>
          
          <Grid item xs={12}>
            <Divider className="my-6" />
          </Grid>
          
          <Grid item xs={12}>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
            >
              <Typography variant="h4" component="h2" className="mb-6 text-center font-serif">
                Key Features
              </Typography>
              <Grid container spacing={4}>
                {[
                  {
                    icon: <HealthAndSafetyIcon fontSize="large" className="text-primary-main" />,
                    title: 'Accurate Prediction',
                    description: 'Our model achieves high accuracy in identifying potential heart disease cases, helping users understand their risk level.'
                  },
                  {
                    icon: <TimelineIcon fontSize="large" className="text-secondary-main" />,
                    title: 'Data Visualization',
                    description: 'Clear visual representation of prediction results and risk factors to help users better understand their health status.'
                  },
                  {
                    icon: <PeopleIcon fontSize="large" className="text-green-600" />,
                    title: 'User-Friendly Interface',
                    description: 'An intuitive and accessible interface designed for users of all technical backgrounds to easily input their health parameters.'
                  },
                  {
                    icon: <SchoolIcon fontSize="large" className="text-amber-600" />,
                    title: 'Educational Resources',
                    description: 'Recommendations and information to help users understand heart disease risk factors and prevention strategies.'
                  }
                ].map((feature, index) => (
                  <Grid item xs={12} sm={6} md={3} key={index}>
                    <Card className="h-full hover:shadow-lg transition-shadow duration-300">
                      <CardContent className="text-center">
                        <Box className="flex justify-center mb-4">
                          {feature.icon}
                        </Box>
                        <Typography variant="h6" component="h3" className="mb-2 font-serif">
                          {feature.title}
                        </Typography>
                        <Typography variant="body2">
                          {feature.description}
                        </Typography>
                      </CardContent>
                    </Card>
                  </Grid>
                ))}
              </Grid>
            </motion.div>
          </Grid>
          
          <Grid item xs={12}>
            <Divider className="my-6" />
          </Grid>
          
          <Grid item xs={12}>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.5 }}
            >
              <Box className="bg-gray-100 p-6 rounded-lg">
                <Typography variant="h4" component="h2" className="mb-4 text-center font-serif">
                  Important Disclaimer
                </Typography>
                <Typography variant="body1" className="text-center mb-4">
                  This heart disease prediction tool is designed for educational and informational purposes only.
                  It should not be considered as a substitute for professional medical advice, diagnosis, or treatment.
                </Typography>
                <Typography variant="body1" className="text-center">
                  Always seek the advice of your physician or other qualified health provider with any
                  questions you may have regarding a medical condition. Never disregard professional
                  medical advice or delay in seeking it because of something you have read or predicted
                  using this tool.
                </Typography>
              </Box>
            </motion.div>
          </Grid>
        </Grid>
      </Container>
    </Box>
  );
};

export default AboutPage;
