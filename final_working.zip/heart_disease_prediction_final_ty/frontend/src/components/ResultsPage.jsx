import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Container, Box, Typography, Paper, Button, Grid, 
  List, ListItem, ListItemText, Divider, CircularProgress
} from '@mui/material';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip as RechartsTooltip } from 'recharts';
import FavoriteIcon from '@mui/icons-material/Favorite';
import WarningIcon from '@mui/icons-material/Warning';
import HealthAndSafetyIcon from '@mui/icons-material/HealthAndSafety';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import { motion } from 'framer-motion';

const getRiskColor = (riskLevel) => {
  switch (riskLevel) {
    case 'Low Risk':
      return '#4caf50';
    case 'Moderate Risk':
      return '#ff9800';
    case 'High Risk':
      return '#f44336';
    case 'Very High Risk':
      return '#b71c1c';
    default:
      return '#2196f3';
  }
};

const ResultsPage = ({ result, formData }) => {
  const navigate = useNavigate();
  
  useEffect(() => {
    if (!result || !formData) {
      navigate('/predict');
    }
  }, [result, formData, navigate]);

  if (!result || !formData) {
    return (
      <Box className="flex justify-center items-center min-h-[60vh]">
        <CircularProgress />
      </Box>
    );
  }

  const { prediction, probability, message, risk_level } = result;
  
  const pieData = [
    { name: 'Risk', value: probability },
    { name: 'Safe', value: 1 - probability }
  ];
  
  const fieldLabels = {
    Age: 'Age',
    Sex: formData.Sex === 1 ? 'Male' : 'Female',
    ChestPainType: ['Typical Angina', 'Atypical Angina', 'Non-anginal Pain', 'Asymptomatic'][formData.ChestPainType],
    RestingBP: `${formData.RestingBP} mm Hg`,
    Cholesterol: `${formData.Cholesterol} mg/dl`,
    FastingBS: formData.FastingBS === 1 ? '> 120 mg/dl' : '< 120 mg/dl',
    RestingECG: ['Normal', 'ST-T wave abnormality', 'Left ventricular hypertrophy'][formData.RestingECG],
    MaxHR: `${formData.MaxHR} bpm`,
    ExerciseAngina: formData.ExerciseAngina === 1 ? 'Yes' : 'No',
    STDepression: formData.STDepression,
    STSlope: ['Upsloping', 'Flat', 'Downsloping'][formData.STSlope],
    MajorVessels: formData.MajorVessels,
    Thalassemia: ['Normal', 'Fixed Defect', 'Reversible Defect', 'Unknown'][formData.Thalassemia]
  };

  const riskColor = getRiskColor(risk_level);
  
  const getRecommendations = () => {
    if (prediction === 0) {
      return [
        'Maintain a healthy lifestyle with regular exercise',
        'Continue with a balanced diet low in saturated fats and sodium',
        'Regular health check-ups to monitor your heart health',
        'Stay hydrated and manage stress effectively',
        'Avoid smoking and limit alcohol consumption'
      ];
    } else {
      return [
        'Consult with a cardiologist for a comprehensive evaluation',
        'Consider additional cardiac tests for a detailed assessment',
        'Follow a heart-healthy diet recommended by your healthcare provider',
        'Regular physical activity as advised by your doctor',
        'Monitor your blood pressure and cholesterol levels regularly',
        'Take prescribed medications consistently'
      ];
    }
  };

  return (
    <Box 
      className="bg-cover bg-center py-8 min-h-[calc(100vh-144px)]" 
      style={{ 
        backgroundImage: 'linear-gradient(rgba(255, 255, 255, 0.9), rgba(255, 255, 255, 0.9)), url(/heart_form_bg.jpg)',
        backgroundAttachment: 'fixed'
      }}
    >
      <Container maxWidth="lg">
        <Button 
          startIcon={<ArrowBackIcon />} 
          onClick={() => navigate('/predict')} 
          className="mb-6"
        >
          Back to Form
        </Button>
        
        <Grid container spacing={4}>
          <Grid item xs={12} md={7}>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <Paper className="p-6 shadow-lg">
                <Box className="flex items-center mb-6">
                  {prediction === 0 ? (
                    <FavoriteIcon className="text-green-500 mr-3" fontSize="large" />
                  ) : (
                    <WarningIcon className="text-red-500 mr-3" fontSize="large" />
                  )}
                  <Typography variant="h4" component="h1" className="font-serif">
                    Prediction Result
                  </Typography>
                </Box>
                
                <Box 
                  className={`p-4 rounded-lg mb-6 ${
                    prediction === 0 ? 'bg-green-100 border-l-4 border-green-500' : 'bg-red-100 border-l-4 border-red-500'
                  }`}
                >
                  <Typography variant="h5" className="font-medium mb-2">
                    {message}
                  </Typography>
                  <Typography variant="body1">
                    Risk Level: <span className="font-bold" style={{ color: riskColor }}>{risk_level}</span>
                  </Typography>
                  <Typography variant="body2" className="mt-1 text-gray-700">
                    Probability: {(probability * 100).toFixed(2)}%
                  </Typography>
                </Box>
                
                <Typography variant="h6" className="mb-4 font-serif">
                  Recommendations
                </Typography>
                
                <List className="bg-gray-50 rounded-lg">
                  {getRecommendations().map((rec, index) => (
                    <div key={index}>
                      <ListItem>
                        <ListItemText primary={rec} />
                      </ListItem>
                      {index < getRecommendations().length - 1 && <Divider />}
                    </div>
                  ))}
                </List>
                
                <Box className="mt-6 pt-4 border-t border-gray-200">
                  <Typography variant="subtitle2" color="textSecondary" className="mb-4">
                    Remember: This prediction is for educational purposes only. Please consult with a healthcare professional for medical advice.
                  </Typography>
                  
                  <Button 
                    variant="contained" 
                    color="primary" 
                    onClick={() => navigate('/predict')}
                    className="bg-primary-main hover:bg-primary-dark"
                  >
                    Make Another Prediction
                  </Button>
                </Box>
              </Paper>
            </motion.div>
          </Grid>
          
          <Grid item xs={12} md={5}>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <Paper className="p-6 shadow-lg mb-6">
                <Typography variant="h6" className="mb-4 font-serif">
                  Risk Visualization
                </Typography>
                
                <Box className="flex justify-center mb-4">
                  <ResponsiveContainer width="100%" height={200}>
                    <PieChart>
                      <Pie
                        data={pieData}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={80}
                        fill="#8884d8"
                        paddingAngle={5}
                        dataKey="value"
                        labelLine={false}
                        label={false}
                      >
                        <Cell key="risk" fill={riskColor} />
                        <Cell key="safe" fill="#e0e0e0" />
                      </Pie>
                      <RechartsTooltip formatter={(value) => `${(value * 100).toFixed(2)}%`} />
                    </PieChart>
                  </ResponsiveContainer>
                </Box>
                
                <Box className="flex justify-center text-center">
                  <Box className="px-4">
                    <Typography variant="h5" className="font-bold" style={{ color: riskColor }}>
                      {(probability * 100).toFixed(1)}%
                    </Typography>
                    <Typography variant="body2" color="textSecondary">
                      Risk Level
                    </Typography>
                  </Box>
                  <Divider orientation="vertical" flexItem className="mx-4" />
                  <Box className="px-4">
                    <Typography variant="h5" className="font-bold text-gray-500">
                      {((1 - probability) * 100).toFixed(1)}%
                    </Typography>
                    <Typography variant="body2" color="textSecondary">
                      Safe Level
                    </Typography>
                  </Box>
                </Box>
              </Paper>
              
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.4 }}
              >
                <Paper className="p-6 shadow-lg">
                  <Typography variant="h6" className="mb-4 font-serif">
                    Your Input Parameters
                  </Typography>
                  
                  <List className="bg-gray-50 rounded-lg">
                    {Object.entries(fieldLabels).map(([key, value], index) => (
                      <div key={key}>
                        <ListItem>
                          <ListItemText 
                            primary={key.replace(/([A-Z])/g, ' $1').trim()} 
                            secondary={value}
                          />
                        </ListItem>
                        {index < Object.entries(fieldLabels).length - 1 && <Divider />}
                      </div>
                    ))}
                  </List>
                </Paper>
              </motion.div>
            </motion.div>
          </Grid>
        </Grid>
      </Container>
    </Box>
  );
};

export default ResultsPage;
