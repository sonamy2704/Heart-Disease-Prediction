// src/components/PredictionForm.jsx
import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import {
    Container, Box, Typography, TextField, MenuItem, Button,
    Grid, Paper, CircularProgress, Slider, Tooltip, Snackbar, Alert,
    Card, CardContent
} from '@mui/material';
import HealthAndSafetyIcon from '@mui/icons-material/HealthAndSafety';

const API_URL = 'http://localhost:5000';

const PredictionForm = ({ onPredictionResult }) => {
    const navigate = useNavigate();
    const [formData, setFormData] = useState({
        Age: 45,
        Sex: 1,
        ChestPainType: 0,
        RestingBP: 120,
        Cholesterol: 200,
        FastingBS: 0,
        RestingECG: 0,
        MaxHR: 150,
        ExerciseAngina: 0,
        STDepression: 0,
        STSlope: 0,
        MajorVessels: 0,
        Thalassemia: 0
    });

    const [metadata, setMetadata] = useState(null);
    const [loading, setLoading] = useState(true);
    const [submitting, setSubmitting] = useState(false);
    const [error, setError] = useState(null);

    useEffect(() => {
        const fetchMetadata = async () => {
            setLoading(true);
            try {
                const response = await axios.get(`${API_URL}/metadata`);
                setMetadata(response.data);
            } catch (err) {
                setError('Failed to load form data. Please try again later.');
                console.error('Error fetching metadata:', err);
            } finally {
                setLoading(false);
            }
        };

        fetchMetadata();
    }, []);

    const handleChange = (event) => {
        const { name, value } = event.target;
        setFormData({
            ...formData,
            [name]: name === 'Age' || name === 'RestingBP' || name === 'Cholesterol' || name === 'MaxHR' ?
                Number(value) :
                (name === 'STDepression' ? parseFloat(value) : Number(value))
        });
    };

    const handleSliderChange = (name) => (event, newValue) => {
        setFormData({
            ...formData,
            [name]: newValue
        });
    };

    const handleSubmit = async (event) => {
        event.preventDefault();
        setSubmitting(true);
        setError(null);

        try {
            const token = localStorage.getItem('token');
            if (!token) {
                navigate('/login');
                return;
            }

            const response = await axios.post(`${API_URL}/predict`, formData, {
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                }
            });

            onPredictionResult(response.data, formData);
            navigate('/results');
        } catch (err) {
            if (err.response?.status === 401) {
                navigate('/login');
            } else {
                setError(err.response?.data?.error || 'Error making prediction. Please try again.');
            }
            console.error('Prediction error:', err);
        } finally {
            setSubmitting(false);
        }
    };

    const handleCloseError = () => {
        setError(null);
    };

    if (loading) {
        return (
            <Box className="flex justify-center items-center min-h-[60vh]">
                <CircularProgress />
            </Box>
        );
    }

    return (
        <Box
            className="bg-cover bg-center py-8 min-h-[calc(100vh-144px)]"
            style={{
                backgroundImage: 'linear-gradient(rgba(255, 255, 255, 0.9), rgba(255, 255, 255, 0.9)), url(/heart_form_bg.jpg)',
                backgroundAttachment: 'fixed'
            }}
        >
            <Container maxWidth="lg">
                <Grid container spacing={4}>
                    <Grid item xs={12} md={4} className="mb-6 md:mb-0">
                        <Box className="sticky top-8">
                            <Typography variant="h4" component="h1" className="mb-4 font-serif">
                                Heart Disease Prediction Form
                            </Typography>

                            <Typography variant="body1" className="mb-6">
                                Please fill in your health parameters to get a personalized heart disease risk assessment.
                                All fields are required for an accurate prediction.
                            </Typography>

                            <Card className="mb-6 bg-primary-main/10">
                                <CardContent>
                                    <Box className="flex items-center mb-3">
                                        <HealthAndSafetyIcon className="mr-2 text-primary-main" />
                                        <Typography variant="h6" component="h2" className="font-serif">
                                            Why This Matters
                                        </Typography>
                                    </Box>
                                    <Typography variant="body2">
                                        Heart disease is the leading cause of death globally. Early prediction can help
                                        with prevention strategies and timely medical interventions.
                                    </Typography>
                                </CardContent>
                            </Card>

                            <Typography variant="body2" className="text-gray-600 italic">
                                Note: This prediction tool is for educational purposes only and should not replace
                                professional medical advice. Always consult with a healthcare provider about your health concerns.
                            </Typography>
                        </Box>
                    </Grid>

                    <Grid item xs={12} md={8}>
                        <Paper className="p-6 shadow-lg">
                            <form onSubmit={handleSubmit}>
                                <Grid container spacing={3}>
                                    {metadata && Object.entries(metadata).map(([field, info]) => (
                                        <Grid item xs={12} sm={6} key={field}>
                                            {info.type === 'select' ? (
                                                <TextField
                                                    select
                                                    fullWidth
                                                    label={field.replace(/([A-Z])/g, ' $1').trim()}
                                                    name={field}
                                                    value={formData[field]}
                                                    onChange={handleChange}
                                                    helperText={info.description}
                                                    required
                                                >
                                                    {info.options.map((option) => (
                                                        <MenuItem key={option.value} value={option.value}>
                                                            {option.label}
                                                        </MenuItem>
                                                    ))}
                                                </TextField>
                                            ) : info.type === 'number' && (info.max - info.min <= 20) ? (
                                                <Box>
                                                    <Typography id={`${field}-slider-label`} gutterBottom>
                                                        {field.replace(/([A-Z])/g, ' $1').trim()} - {formData[field]} {field === 'STDepression' ? '' : (field === 'Age' ? ' years' : '')}
                                                    </Typography>
                                                    <Tooltip title={info.description} placement="top">
                                                        <Slider
                                                            value={formData[field]}
                                                            onChange={handleSliderChange(field)}
                                                            aria-labelledby={`${field}-slider-label`}
                                                            valueLabelDisplay="auto"
                                                            step={field === 'STDepression' ? 0.1 : 1}
                                                            marks
                                                            min={info.min}
                                                            max={info.max}
                                                            className="mt-6"
                                                        />
                                                    </Tooltip>
                                                </Box>
                                            ) : (
                                                <TextField
                                                    fullWidth
                                                    label={field.replace(/([A-Z])/g, ' $1').trim()}
                                                    name={field}
                                                    type="number"
                                                    value={formData[field]}
                                                    onChange={handleChange}
                                                    helperText={info.description}
                                                    required
                                                    inputProps={{
                                                        min: info.min,
                                                        max: info.max,
                                                        step: info.step || 1
                                                    }}
                                                />
                                            )}
                                        </Grid>
                                    ))}

                                    <Grid item xs={12} className="mt-4 text-center">
                                        <Button
                                            type="submit"
                                            variant="contained"
                                            size="large"
                                            className="bg-primary-main hover:bg-primary-dark px-8 py-3"
                                            disabled={submitting}
                                        >
                                            {submitting ? (
                                                <>
                                                    <CircularProgress size={24} className="mr-2" />
                                                    Processing...
                                                </>
                                            ) : 'Get Prediction'}
                                        </Button>
                                    </Grid>
                                </Grid>
                            </form>
                        </Paper>
                    </Grid>
                </Grid>
            </Container>

            <Snackbar open={!!error} autoHideDuration={6000} onClose={handleCloseError}>
                <Alert onClose={handleCloseError} severity="error">
                    {error}
                </Alert>
            </Snackbar>
        </Box>
    );
};

export default PredictionForm;
