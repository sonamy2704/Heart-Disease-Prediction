import React from 'react';
import { useLocation } from 'react-router-dom';
import { Box, Container, Typography, Grid, Link } from '@mui/material';
import FavoriteIcon from '@mui/icons-material/Favorite';

const Footer = () => {
  const location = useLocation();

  // Define routes where Footer content should be minimal
  const excludeRoutes = ['/login', '/register', '/forgot-password'];

  return (
    <Box className="bg-gray-900 text-white py-6">
      <Container maxWidth="lg">
        <Grid container spacing={4}>

          {/* Main Footer Content - Displayed on all pages except excluded routes */}
          {!excludeRoutes.includes(location.pathname) ? (
            <>
              <Grid item xs={12} md={4}>
                <Typography variant="h6" className="flex items-center mb-2">
                  <FavoriteIcon color="error" className="mr-2" />
                  Heart Disease Predictor
                </Typography>
                <Typography variant="body2" color="textSecondary">
                  An ML-powered tool to help predict the risk of heart disease based on health parameters.
                </Typography>
              </Grid>

              <Grid item xs={12} md={4}>
                <Typography variant="h6" className="mb-2">Quick Links</Typography>
                <Link href="/" color="inherit" underline="hover" className="block">
                  Home
                </Link>
                <Link href="/predict" color="inherit" underline="hover" className="block">
                  Predict
                </Link>
                <Link href="/about" color="inherit" underline="hover" className="block">
                  About
                </Link>
              </Grid>

              <Grid item xs={12} md={4}>
                <Typography variant="h6" className="mb-2">Connect</Typography>
                <Box className="flex space-x-3">
                  <Link href="#" color="inherit" underline="hover">
                    LinkedIn
                  </Link>
                  <Link href="#" color="inherit" underline="hover">
                    GitHub
                  </Link>
                  <Link href="#" color="inherit" underline="hover">
                    Email
                  </Link>
                </Box>
              </Grid>
            </>
          ) : (
            /* Minimal Footer Content - Only Copyright */
            <Grid item xs={12}>
              <Typography variant="body2" color="textSecondary" align="center">
                &copy; {new Date().getFullYear()} Heart Disease Predictor. All rights reserved.
              </Typography>
            </Grid>
          )}
        </Grid>

        {/* Copyright - Always Displayed */}
        {/* Conditional rendering is removed as it's now part of the main condition */}
      </Container>
    </Box>
  );
};

export default Footer;
