import { createContext, useState, useEffect, useCallback } from 'react';
import axios from 'axios';

export const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
    const [currentUser, setCurrentUser] = useState(null);
    const [loading, setLoading] = useState(true);

    const loadStoredUser = useCallback(() => {
        const storedUser = localStorage.getItem('user');

        if (storedUser) {
            const user = JSON.parse(storedUser);
            setCurrentUser(user);
            console.log("Loaded user from local storage:", user);
        } else {
            setCurrentUser(null);
            localStorage.removeItem('user');
            console.log("No user found in local storage.");
        }

        setLoading(false);
    }, []);

    useEffect(() => {
        loadStoredUser();
    }, [loadStoredUser]);

    const login = async (username, password) => {
        try {
            const response = await axios.post('http://localhost:5000/api/login', {
                username,
                password
            });

            const { access_token, username: user } = response.data;

            localStorage.setItem('token', access_token);
            localStorage.setItem('user', JSON.stringify({ username: user }));


            setCurrentUser({ username: user });
            console.log("Login successful:", { username: user });
            return { success: true, user: { username: user } };
        } catch (error) {
            console.error("Login failed:", error.response ? error.response.data : error.message);
            logout();
            return {
                success: false,
                message: error.response?.data?.message || 'Login failed'
            };
        }
    };

    const register = async (username, email, password) => {
        try {
            const response = await axios.post('http://localhost:5000/api/register', {
                username,
                email,
                password
            });

            const { access_token, username: user } = response.data;

            localStorage.setItem('token', access_token);
            localStorage.setItem('user', JSON.stringify({ username: user }));


            setCurrentUser({ username: user });
            console.log("Registration successful:", { username: user });
            return { success: true, user: { username: user } };
        } catch (error) {
            console.error("Registration failed:", error.response ? error.response.data : error.message);
            return {
                success: false,
                message: error.response?.data?.error || 'Registration failed'
            };
        }
    };

    const resetPassword = async (username, password) => {
        try {
            const response = await axios.post('http://localhost:5000/api/reset_password', {
                username,
                password,
            });

            return { success: true, message: response.data.message };
        } catch (error) {
            console.error("Reset password failed:", error.response ? error.response.data : error.message);
            return {
                success: false,
                message: error.response?.data?.message || 'Reset password failed'
            };
        }
    };


    const logout = () => {
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        setCurrentUser(null);
        console.log("Logout successful");
    };

    const contextValue = {
        currentUser,
        login,
        register,
        logout,
        loading,
        resetPassword,
    };

    return (
        <AuthContext.Provider value={contextValue}>
            {children}
        </AuthContext.Provider>
    );
};
