import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import joblib
import pickle
import os

np.random.seed(42)

# Load dataset
data = pd.read_csv('./data/heart.csv')

# Column renaming
column_mapping = {
    'Chest pain type': 'ChestPainType',
    'BP': 'RestingBP',
    'Cholesterol': 'Cholesterol',
    'FBS over 120': 'FastingBS',
    'EKG results': 'RestingECG',
    'Max HR': 'MaxHR',
    'Exercise angina': 'ExerciseAngina',
    'ST depression': 'STDepression',
    'Slope of ST': 'STSlope',
    'Number of vessels fluro': 'MajorVessels',
    'Thallium': 'Thalassemia',
    'Heart Disease': 'HeartDisease'
}

data.rename(columns=column_mapping, inplace=True)

# Convert HeartDisease labels to numeric
data['HeartDisease'] = data['HeartDisease'].map({'Absence': 0, 'Presence': 1})

# Drop rows with missing target
data.dropna(subset=['HeartDisease'], inplace=True)

# Print unique target values to verify
print("Target value counts:\n", data['HeartDisease'].value_counts())

# Drop any remaining NA values
data.dropna(inplace=True)

# Drop unnecessary feature engineering columns if already present
X = data.drop(['HeartDisease'], axis=1)
y = data['HeartDisease']

# Split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Scale
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Models
models = {
    'Random Forest': RandomForestClassifier(random_state=42),
    'Gradient Boosting': GradientBoostingClassifier(random_state=42),
    'SVM': SVC(probability=True, random_state=42)
}

# Evaluate
model_results = {}
for name, model in models.items():
    print(f"\nTraining {name}...")
    model.fit(X_train_scaled, y_train)
    y_pred = model.predict(X_test_scaled)
    acc = accuracy_score(y_test, y_pred)
    model_results[name] = acc
    print(f"{name} Accuracy: {acc:.4f}")
    print("Classification Report:\n", classification_report(y_test, y_pred))
    print("Confusion Matrix:\n", confusion_matrix(y_test, y_pred))

# Best model
best_model_name = max(model_results, key=model_results.get)
best_model = models[best_model_name]
print(f"\nBest Model: {best_model_name}")

# Hyperparameter tuning
if best_model_name == 'Random Forest':
    param_grid = {
        'n_estimators': [100, 200],
        'max_depth': [None, 10, 20],
        'min_samples_split': [2, 5],
        'min_samples_leaf': [1, 2]
    }
elif best_model_name == 'Gradient Boosting':
    param_grid = {
        'n_estimators': [100, 200],
        'learning_rate': [0.05, 0.1],
        'max_depth': [3, 5],
        'min_samples_split': [2, 5]
    }
else:
    param_grid = {
        'C': [1, 10],
        'gamma': ['scale', 0.1],
        'kernel': ['rbf', 'poly']
    }

grid = GridSearchCV(best_model, param_grid, cv=3, scoring='accuracy')
grid.fit(X_train_scaled, y_train)
final_model = grid.best_estimator_

# Save model, scaler, columns
if not os.path.exists('models'):
    os.makedirs('models')

pickle.dump(final_model, open('models/heart_disease_model.pkl', 'wb'))
pickle.dump(scaler, open('models/scaler.pkl', 'wb'))
joblib.dump(list(X.columns), 'models/model_columns.pkl')

print("\nModel, scaler, and columns saved successfully.")
