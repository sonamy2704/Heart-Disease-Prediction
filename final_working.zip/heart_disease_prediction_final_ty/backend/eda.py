import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os

# Load the dataset
try:
    data = pd.read_csv('heart.csv')
except FileNotFoundError:
    print("Error: The file 'data/heart.csv' was not found.")
    exit()

# Rename columns for better understanding
column_mapping = {
    'age': 'Age',
    'sex': 'Sex',
    'cp': 'ChestPainType',
    'Chest pain type': 'ChestPainType',
    'trestbps': 'RestingBP',
    'BP': 'RestingBP',
    'chol': 'Cholesterol',
    'Cholesterol': 'Cholesterol',
    'fbs': 'FastingBS',
    'FBS over 120': 'FastingBS',
    'restecg': 'RestingECG',
    'EKG results': 'RestingECG',
    'thalach': 'MaxHR',
    'Max HR': 'MaxHR',
    'exang': 'ExerciseAngina',
    'Exercise angina': 'ExerciseAngina',
    'oldpeak': 'STDepression',
    'ST depression': 'STDepression',
    'slope': 'STSlope',
    'Slope of ST': 'STSlope',
    'ca': 'MajorVessels',
    'Number of vessels fluro': 'MajorVessels',
    'thal': 'Thalassemia',
    'Thallium': 'Thalassemia',
    'target': 'HeartDisease',
    'Heart Disease': 'HeartDisease'
}

# Check if the columns exist before renaming
existing_columns = data.columns
columns_to_rename = {k: v for k, v in column_mapping.items() if k in existing_columns}

# Rename the columns
data = data.rename(columns=columns_to_rename)

# Convert HeartDisease to numeric if it contains strings
if data['HeartDisease'].dtype == 'object':
    data['HeartDisease'] = data['HeartDisease'].map({'Absence': 0, 'Presence': 1})

# Identify non-numeric columns and convert them to numeric
for col in data.columns:
    try:
        data[col] = pd.to_numeric(data[col], errors='raise')
    except ValueError as e:
        print(f"Could not convert column {col} to numeric. {e}")
        exit()

# Drop rows with NaN values after conversion
data = data.dropna()

# Create 'data' directory if it doesn't exist
if not os.path.exists('data'):
    os.makedirs('data')

# Set up the figure size
plt.figure(figsize=(12, 10))
# Correlation heatmap
sns.heatmap(data.corr(), annot=True, cmap='coolwarm', linewidths=0.5)
plt.title('Correlation Heatmap')
plt.savefig('data/correlation_heatmap.png')
plt.close()

# Distribution of target variable
plt.figure(figsize=(10, 6))
sns.countplot(x='HeartDisease', data=data)
plt.title('Heart Disease Distribution')
plt.savefig('data/target_distribution.png')
plt.close()

# Age distribution by heart disease
plt.figure(figsize=(10, 6))
sns.histplot(data=data, x='Age', hue='HeartDisease', multiple='stack', bins=20)
plt.title('Age Distribution by Heart Disease Status')
plt.savefig('data/age_distribution.png')
plt.close()

print("EDA visualizations saved to the data directory.")
