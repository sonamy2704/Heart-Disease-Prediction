from flask import Flask, request, jsonify
from flask_cors import CORS
import pickle
import numpy as np
import pandas as pd
import joblib
from flask_jwt_extended import JWTManager, create_access_token, jwt_required, get_jwt_identity
from models import db, User
import os
import secrets
from flask_mail import Mail, Message
import bcrypt
from itsdangerous import URLSafeTimedSerializer

app = Flask(__name__)
CORS(app, supports_credentials=True)

# Configure database
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///heart_disease_prediction.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = "testsecrectkey" #DO NOT CHANGE THIS, IF YOU DO, ALL CODES BREAK

db.init_app(app)
jwt = JWTManager(app)

# Create database tables
with app.app_context():
    db.create_all()

# Load the model and scaler
try:
    model = pickle.load(open('models/heart_disease_model.pkl', 'rb'))
    scaler = pickle.load(open('models/scaler.pkl', 'rb'))
    model_columns = joblib.load('models/model_columns.pkl')
except FileNotFoundError as e:
    print(f"Error loading model or scaler: {e}")
    exit()

@app.route('/api/register', methods=['POST'])
def register():
    data = request.get_json()
    username = data.get('username')
    email = data.get('email')
    password = data.get('password')

    if not username or not email or not password:
        return jsonify({'message': 'Missing fields'}), 400

    existing_user = User.query.filter_by(username=username).first()
    if existing_user:
        return jsonify({'message': 'Username already exists'}), 400

    existing_email = User.query.filter_by(email=email).first()
    if existing_email:
        return jsonify({'message': 'Email already exists'}), 400

    user = User(username=username, email=email, password=password)
    db.session.add(user)
    db.session.commit()

    return jsonify({'message': 'User registered successfully'}), 201

@app.route('/api/login', methods=['POST'])
def login():
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')

    if not username or not password:
        return jsonify({'message': 'Missing fields'}), 400

    user = User.query.filter_by(username=username).first()
    if not user or user.password != password:
        return jsonify({'message': 'Invalid credentials'}), 401

    access_token = create_access_token(identity=username)
    return jsonify(access_token=access_token, message='Logged in successfully!'), 200

@app.route('/api/reset_password', methods=['POST'])
def reset_password():
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')

    if not username or not password:
        return jsonify({'message': 'Username and password are required'}), 400

    user = User.query.filter_by(username=username).first()
    if not user:
        return jsonify({'message': 'Invalid username'}), 400

    user.password = password
    db.session.commit()
    return jsonify({'message': 'Password reset successfully!'}), 200

@app.route('/api/profile', methods=['GET'])
@jwt_required()
def profile():
    current_user = get_jwt_identity()
    user = User.query.filter_by(username=current_user).first()
    
    return jsonify({
        'username': user.username,
        'email': user.email,
        'created_at': user.created_at
    }), 200

@app.route('/predict', methods=['POST'])
@jwt_required()  # Now this endpoint requires authentication
def predict():
    try:
        json_data = request.get_json()

        # Print received JSON data for debugging
        print("Received JSON data:", json_data)

        # Create a DataFrame from the JSON data
        query_df = pd.DataFrame([json_data])

        # Ensure all expected features are present in json_data
        for col in model_columns:
            if col not in query_df.columns:
                return jsonify({'error': f"Missing feature: {col}"}), 400

        # Ensure the order of columns matches the training data and their datatypes
        query_df = query_df[model_columns].astype(float)

        # Scale the features
        query_scaled = scaler.transform(query_df)

        # Make prediction
        prediction = model.predict(query_scaled)
        prediction_proba = model.predict_proba(query_scaled)

        # Format response
        result = {
            'prediction': int(prediction[0]),
            'probability': float(prediction_proba[0][1]),
            'message': 'Heart disease detected!' if prediction[0] == 1 else 'No heart disease detected.',
            'risk_level': get_risk_level(prediction_proba[0][1])
        }

        return jsonify(result)

    except Exception as e:
        return jsonify({'error': str(e)}), 500

def get_risk_level(probability):
    if probability < 0.2:
        return 'Low Risk'
    elif probability < 0.5:
        return 'Moderate Risk'
    elif probability < 0.7:
        return 'High Risk'
    else:
        return 'Very High Risk'
    
@app.route('/metadata', methods=['GET'])
def metadata():
    metadata = {
        'Age': {
            'type': 'number',
            'min': 20,
            'max': 100,
            'description': 'Age of the patient in years'
        },
        'Sex': {
            'type': 'select',
            'options': [
                {'value': 1, 'label': 'Male'},
                {'value': 0, 'label': 'Female'}
            ],
            'description': 'Gender of the patient'
        },
        'ChestPainType': {
            'type': 'select',
            'options': [
                {'value': 0, 'label': 'Typical Angina'},
                {'value': 1, 'label': 'Atypical Angina'},
                {'value': 2, 'label': 'Non-anginal Pain'},
                {'value': 3, 'label': 'Asymptomatic'}
            ],
            'description': 'Type of chest pain experienced'
        },
        'RestingBP': {
            'type': 'number',
            'min': 80,
            'max': 200,
            'description': 'Resting blood pressure in mm Hg'
        },
        'Cholesterol': {
            'type': 'number',
            'min': 100,
            'max': 600,
            'description': 'Serum cholesterol in mg/dl'
        },
        'FastingBS': {
            'type': 'select',
            'options': [
                {'value': 0, 'label': 'Fasting blood sugar < 120 mg/dl'},
                {'value': 1, 'label': 'Fasting blood sugar > 120 mg/dl'}
            ],
            'description': 'Fasting blood sugar'
        },
        'RestingECG': {
            'type': 'select',
            'options': [
                {'value': 0, 'label': 'Normal'},
                {'value': 1, 'label': 'ST-T wave abnormality'},
                {'value': 2, 'label': 'Left ventricular hypertrophy'}
            ],
            'description': 'Resting electrocardiographic results'
        },
        'MaxHR': {
            'type': 'number',
            'min': 60,
            'max': 220,
            'description': 'Maximum heart rate achieved'
        },
        'ExerciseAngina': {
            'type': 'select',
            'options': [
                {'value': 0, 'label': 'No'},
                {'value': 1, 'label': 'Yes'}
            ],
            'description': 'Exercise induced angina'
        },
        'STDepression': {
            'type': 'number',
            'min': 0,
            'max': 6.2,
            'step': 0.1,
            'description': 'ST depression induced by exercise relative to rest'
        },
        'STSlope': {
            'type': 'select',
            'options': [
                {'value': 0, 'label': 'Upsloping'},
                {'value': 1, 'label': 'Flat'},
                {'value': 2, 'label': 'Downsloping'}
            ],
            'description': 'Slope of the peak exercise ST segment'
        },
        'MajorVessels': {
            'type': 'select',
            'options': [
                {'value': 0, 'label': '0'},
                {'value': 1, 'label': '1'},
                {'value': 2, 'label': '2'},
                {'value': 3, 'label': '3'},
                {'value': 4, 'label': '4'}
            ],
            'description': 'Number of major vessels colored by fluoroscopy'
        },
        'Thalassemia': {
            'type': 'select',
            'options': [
                {'value': 0, 'label': 'Normal'},
                {'value': 1, 'label': 'Fixed Defect'},
                {'value': 2, 'label': 'Reversible Defect'},
                {'value': 3, 'label': 'Unknown'}
            ],
            'description': 'Thalassemia type'
        }
    }
    return jsonify(metadata)

if __name__ == '__main__':
    app.run(debug=True, port=5000)
